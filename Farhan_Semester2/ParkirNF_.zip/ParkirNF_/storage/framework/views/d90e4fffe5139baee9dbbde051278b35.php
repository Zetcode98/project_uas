

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e(isset($jenis) ? 'Edit Jenis' : 'Tambah Jenis'); ?></h2>
    <form action="<?php echo e(isset($jenis) ? route('jenis.update', $jenis->id) : route('jenis.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($jenis)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e(old('nama', $jenis->nama ?? '')); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo e(isset($jenis) ? 'Update' : 'Simpan'); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\jenis\form.blade.php ENDPATH**/ ?>