

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e(isset($areaParkir) ? 'Edit Area Parkir' : 'Tambah Area Parkir'); ?></h2>
    <form action="<?php echo e(isset($areaParkir) ? route('areaparkir.update', $areaParkir->id) : route('areaparkir.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($areaParkir)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e(old('nama', $areaParkir->nama ?? '')); ?>" required>
        </div>
        <div class="form-group">
            <label for="kapasitas">Kapasitas:</label>
            <input type="number" name="kapasitas" id="kapasitas" class="form-control" value="<?php echo e(old('kapasitas', $areaParkir->kapasitas ?? '')); ?>" required>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan:</label>
            <textarea name="keterangan" id="keterangan" class="form-control"><?php echo e(old('keterangan', $areaParkir->keterangan ?? '')); ?></textarea>
        </div>
        <div class="form-group">
            <label for="kampus_id">Kampus:</label>
            <select name="kampus_id" id="kampus_id" class="form-control" required>
                <?php $__currentLoopData = $list_kampus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kampus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kampus->id); ?>" <?php echo e(old('kampus_id', $areaParkir->kampus_id ?? '') == $kampus->id ? 'selected' : ''); ?>><?php echo e($kampus->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo e(isset($areaParkir) ? 'Update' : 'Simpan'); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\areaparkir\form.blade.php ENDPATH**/ ?>