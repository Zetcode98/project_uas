<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Admin Dashboard</h1>
    <!-- Konten Admin -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\admin\admin.blade.php ENDPATH**/ ?>