<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Daftar Area Parkir</h2>
    <a href="<?php echo e(route('areaparkir.create')); ?>" class="btn btn-primary">Tambah Area Parkir</a>
    <table id="table" class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Kapasitas</th>
                <th>Keterangan</th>
                <th>ID Kampus</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list_areaparkir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $areaParkir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($areaParkir->nama); ?></td>
                <td><?php echo e($areaParkir->kapasitas); ?></td>
                <td><?php echo e($areaParkir->keterangan); ?></td>
                <td><?php echo e($areaParkir->kampus_id); ?></td>
                <td>
                    <a type="button" class="btn btn-primary mb-2" href="<?php echo e(route('areaparkir.view', $areaParkir->id)); ?>">View</a>
                    <a type="button" class="btn btn-success mb-2" href="<?php echo e(route('areaparkir.edit', $areaParkir->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('areaparkir.destroy', $areaParkir->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger mb-2">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $('#table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\areaparkir\index.blade.php ENDPATH**/ ?>