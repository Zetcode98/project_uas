

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e(isset($parkir) ? 'Edit Parkir' : 'Tambah Parkir'); ?></h2>
    <form action="<?php echo e(isset($parkir) ? route('parkir.update', $parkir->id) : route('parkir.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($parkir)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <div class="form-group">
            <label for="merk">Merk:</label>
            <input type="text" name="merk" id="merk" class="form-control" value="<?php echo e(old('merk', $parkir->merk ?? '')); ?>" required>
        </div>
        <!-- field lain sesuai kebutuhan -->
        <button type="submit" class="btn btn-primary"><?php echo e(isset($parkir) ? 'Update' : 'Simpan'); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\parkir\form.blade.php ENDPATH**/ ?>