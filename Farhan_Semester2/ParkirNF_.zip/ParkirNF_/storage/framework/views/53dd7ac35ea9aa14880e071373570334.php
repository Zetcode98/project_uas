

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Detail Jenis</h2>
    <p><strong>Nama:</strong> <?php echo e($jenis->nama); ?></p>
    <a href="<?php echo e(route('jenis.index')); ?>" class="btn btn-primary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\jenis\view.blade.php ENDPATH**/ ?>