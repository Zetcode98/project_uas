

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Tambah Kendaraan</h2>
    <form action="<?php echo e(route('parkir.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="merk">Merk Kendaraan:</label>
            <input type="text" name="merk" id="merk" class="form-control" value="<?php echo e(old('merk')); ?>" required>
        </div>
        <div class="form-group">
            <label for="pemilik">Nama Pemilik:</label>
            <input type="text" name="pemilik" id="pemilik" class="form-control" value="<?php echo e(old('pemilik')); ?>" required>
        </div>
        <div class="form-group">
            <label for="nopol">Nomor Polisi:</label>
            <input type="text" name="nopol" id="nopol" class="form-control" value="<?php echo e(old('nopol')); ?>" required>
        </div>
        <div class="form-group">
            <label for="thn_beli">Tahun Beli:</label>
            <input type="text" name="thn_beli" id="thn_beli" class="form-control" value="<?php echo e(old('thn_beli')); ?>" required>
        </div>
        <div class="form-group">
            <label for="kapasitas_kursi">Kapasitas Kursi:</label>
            <input type="number" name="kapasitas_kursi" id="kapasitas_kursi" class="form-control" value="<?php echo e(old('kapasitas_kursi')); ?>" required>
        </div>
        <div class="form-group">
            <label for="deskripsi">Deskripsi:</label>
            <textarea name="deskripsi" id="deskripsi" class="form-control"><?php echo e(old('deskripsi')); ?></textarea>
        </div>
        <div class="form-group">
            <label for="jenis_kendaraan_id">Jenis Kendaraan:</label>
            <select name="jenis_kendaraan_id" id="jenis_kendaraan_id" class="form-control" required>
                <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e(old('jenis_kendaraan_id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\parkir\create.blade.php ENDPATH**/ ?>