<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('card_title', null, []); ?> Kendaraan <?php $__env->endSlot(); ?>
    <table id="table" class="table" table-bordered table-hover>
        <thead>
            <tr>
                <th>id</th>
                <th>Merk</th>
                <th>Pemilik</th>
                <th>Plat Nomor</th>
                <th>Tahun Beli</th>
                <th>Deskripsi</th>
                <th>Jenis</th>
                <th>Kapasitas</th>
                <th>Rating</th>
                <th>ID Jenis</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list_kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kendaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($Kendaraan->merk); ?></td>
                <td><?php echo e($Kendaraan->pemilik); ?></td>
                <td><?php echo e($Kendaraan->nopol); ?></td>
                <td><?php echo e($Kendaraan->thn_beli); ?></td>
                <td><?php echo e($Kendaraan->deskripsi); ?></td>
                <td><?php echo e($Kendaraan->jenis_kendaraan_id); ?></td>
                <td><?php echo e($Kendaraan->kapasitas_kursi); ?></td>
                <td><?php echo e($Kendaraan->rating); ?></td>
                <td><?php echo e($Kendaraan->jenis_id); ?></td>
                <td>
                <a type="button" class="btn btn-primary mb-2" href="">View</a> | <a type="button" class="btn btn-success mb-2" href="#?id=<?php echo e($Jenis->id); ?>&edit=edit">Edit</a> |
                <a type="button" class="btn btn-danger mb-2" href="#?id=<?php echo e($Jenis->id); ?>&delete=delete">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $('#table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\kendaraan\index.blade.php ENDPATH**/ ?>