

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Detail Parkir</h2>
    <p><strong>Merk:</strong> <?php echo e($parkir->merk); ?></p>
    <p><strong>Pemilik:</strong> <?php echo e($parkir->pemilik); ?></p>
    <!-- field lain sesuai kebutuhan -->
    <a href="<?php echo e(route('parkir.index')); ?>" class="btn btn-primary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\parkir\view.blade.php ENDPATH**/ ?>