

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Detail Area Parkir</h2>
    <p><strong>Nama:</strong> <?php echo e($areaParkir->nama); ?></p>
    <p><strong>Kapasitas:</strong> <?php echo e($areaParkir->kapasitas); ?></p>
    <p><strong>Keterangan:</strong> <?php echo e($areaParkir->keterangan); ?></p>
    <p><strong>Kampus:</strong> <?php echo e($areaParkir->kampus_id); ?></p>
    <a href="<?php echo e(route('areaparkir.index')); ?>" class="btn btn-primary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\areaparkir\view.blade.php ENDPATH**/ ?>