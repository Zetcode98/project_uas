

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Daftar Parkir</h2>
    <a href="<?php echo e(route('create')); ?>" class="btn btn-primary">Tambah Parkir</a>
    <table class="table">
        <thead>
            <tr>
                <th>Merk</th>
                <th>Pemilik</th>
                <!-- kolom lain sesuai kebutuhan -->
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list_parkir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parkir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($parkir->merk); ?></td>
                    <td><?php echo e($parkir->pemilik); ?></td>
                    <!-- kolom lain sesuai kebutuhan -->
                    <td>
                        <a href="<?php echo e(route('parkir.view', $parkir->id)); ?>" class="btn btn-info">View</a>
                        <a href="<?php echo e(route('parkir.edit', $parkir->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('parkir.destroy', $parkir->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views\parkir\index.blade.php ENDPATH**/ ?>