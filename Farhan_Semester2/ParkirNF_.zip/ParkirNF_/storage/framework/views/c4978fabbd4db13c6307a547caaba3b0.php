<!-- resources/views/dashboard.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Dashboard</h1>
    <ul>
        <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('admin')); ?>">Admin</a></li>
        <li><a href="<?php echo e(route('areaparkir.index')); ?>">Area Parkir</a></li>
        <li><a href="<?php echo e(route('jenis.index')); ?>">Jenis</a></li>
        <li><a href="<?php echo e(route('kampus.index')); ?>">Kampus</a></li>
        <li><a href="<?php echo e(route('kendaraan.index')); ?>">Kendaraan</a></li>
        <li><a href="<?php echo e(route('transaksi.index')); ?>">Transaksi</a></li>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farhan_Semester2\ParkirNF_\resources\views/dashboard.blade.php ENDPATH**/ ?>